internal class ChatBox
{
}
